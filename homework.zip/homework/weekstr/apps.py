from django.apps import AppConfig


class WeekstrConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'weekstr'
