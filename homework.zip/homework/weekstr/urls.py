from django.urls import path
from .views import index,show_weekstr, show_weekstr_eng,show_weekstr_uzb,show_weekstr_rus

urlpatterns = [
    path('', index, name='index'),
    path('weekdays/', show_weekstr, name='week'),
    path('weekdays/eng/', show_weekstr_eng, name='week_eng'),
    path('weekdays/uzb/', show_weekstr_uzb, name='week_uzb'),
    path('weekdays/rus/', show_weekstr_rus, name='week_rus'),
]
