from django.http import HttpResponse
from django.shortcuts import render

weekstr = [
    {"eng":"Monday", "uzb": "Dushanba", "rus": "Понедельник"},
    {"eng":"Tuesday","uzb": "Seshanba", "rus": "Вторник"},
    {"eng":"Wednesday","uzb": "Chorshanba", "rus": "Среда"},
    {"eng":"Thursday","uzb": "Payshanba", "rus": "Четверг"},
    {"eng":"Friday","uzb": "Juma", "rus": "Пятница"},
    {"eng":"Saturday","uzb": "Shanba", "rus": "Суббота"},
    {"eng":"Sunday","uzb": "Yakshanba", "rus": "Воскресенье"},
]
def index(request):
    return render(request, 'index.html')
def show_weekstr(request):
    global weekstr
    return render(request, 'week.html', context={'weekstr': weekstr})

def show_weekstr_eng(request):
    global weekstr
    return render(request, 'week_eng.html', context={'weekstr': weekstr})

def show_weekstr_uzb(request):
    global weekstr
    return render(request, 'week_uzb.html', context={'weekstr': weekstr})

def show_weekstr_rus(request):
    global weekstr
    return render(request, 'week_rus.html', context={'weekstr': weekstr})